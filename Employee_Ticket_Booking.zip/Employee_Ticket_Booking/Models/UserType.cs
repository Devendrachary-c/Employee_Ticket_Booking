﻿using System;
using System.Collections.Generic;

namespace Employee_Ticket_Booking.Models;

    public partial class UserType
    {
        public int Id { get; set; }
        public  string Name { get; set; }
        public string Description { get; set; }
    }


﻿namespace Employee_Ticket_Booking.Models
{
    public class LoginModel
    {
        public required string Email { get; set; }
        public required string UserName { get; set; }
        public required string Password { get; set; }
    }
}
